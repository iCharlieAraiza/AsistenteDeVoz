const start = document.getElementById("start");
const texts = document.querySelector(".texts");

window.SpeechRecognition =
window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

start.onclick = ()=>{
    if(start.classList.contains("active-record")){
        start.classList.remove("active-record");
        location.reload()
    }else{
        start.classList.add("active-record");
    }
    

    recognition.interimResults = true;

    let p = document.createElement("p");

recognition.addEventListener("result", (e) => {
texts.appendChild(p);
const text = Array.from(e.results)
    .map((result) => result[0])
    .map((result) => result.transcript)
    .join("");

p.innerText = text;
if (e.results[0].isFinal) {
    if (text.includes("Hola")) {
        p.classList.add("replay");
        p.innerText = "Hola, tú";
        texts.appendChild(p);
    }
    if (text.includes("Cómo estás")) {
    p = document.createElement("p");
    p.classList.add("replay");
    p.innerText = "Bien y tú?";
    texts.appendChild(p);
    }
    if(text.includes("Dame la hora")){
        const d = new Date();
        p.classList.add("replay");
        p.innerText = d.getHours() + ":" + d.getMinutes();
        texts.appendChild(p);
    }
    if(text.includes("Adiós")){
        const d = new Date();
        p.classList.add("replay");
        p.innerText = "Adiós";
        texts.appendChild(p);
    }
    if(text.includes("Apagar")|| text.includes("apagar")){
        p.classList.add("replay");
        p.innerText = "Apagando...";
        texts.appendChild(p);
        //document.getElementById("main").classList.add("off");
    }

    if(text.toLowerCase().includes("recomienda música similar")){
        p = document.createElement("p");
        p.classList.add("replay");
        let response = text.toLowerCase();
        const regex = /recomienda música similar/gi;

        response = response.replace(regex, '');

        p.innerText = response;
        texts.appendChild(p);
    }

    if(text.toLowerCase().includes("prender") || text.toLowerCase().includes("prende")){
        p.classList.add("replay");
        p.innerText = "Prendiendo...";
        texts.appendChild(p);
        document.getElementById("main").classList.remove("off");
    }

    if (text.toLowerCase().includes("abre youtube")) {
    p = document.createElement("p");
    p.classList.add("replay");
    p.innerText = "Abriendo YouTube";
    texts.appendChild(p);
    console.log("Abriendo YouTube");
    window.open("https://www.youtube.com/");
    }
    p = document.createElement("p");
}
});

recognition.addEventListener("end", () => {
recognition.start();
});

recognition.start();

}