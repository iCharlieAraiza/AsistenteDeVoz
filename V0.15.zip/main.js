const form = document.getElementById("configForm");

document.getElementById("closeBtn").onclick = ()=>{
    if(!form.classList.contains("hide-form")){
        form.classList.add("hide-form");
    }
}

document.getElementById("configBtn").onclick = ()=>{
    if(form.classList.contains("hide-form")){
        form.classList.remove("hide-form");
    }
}

document.getElementById("saveBtn").onclick = ()=>{
    
    document.getElementById("loader").style.display= "inline-block";
    document.getElementById("confirm-save-label").style.display= "none";

    setTimeout( ()=>{
        document.getElementById("loader").style.display= "none";
        document.getElementById("confirm-save-label").style.display= "inline-block";
        }, 3000);
    
}
