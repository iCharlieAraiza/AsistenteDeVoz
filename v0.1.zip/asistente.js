const start = document.getElementById("start");

start.onclick = ()=>{
    if(start.classList.contains("active-record")){
        start.classList.remove("active-record");
    }else{
        start.classList.add("active-record");
    }
    status.innerText = "Activo";
    status.style.color = "green";
    start.disabled = true;
    
    window.SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

}